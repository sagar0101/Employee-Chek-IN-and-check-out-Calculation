--Create Input Table:
CREATE TABLE EmployeeLogin (
    EmpID INT,
    Name VARCHAR(50),
    CheckInCheckOutTime DATETIME,
    Attendance VARCHAR(3)
);