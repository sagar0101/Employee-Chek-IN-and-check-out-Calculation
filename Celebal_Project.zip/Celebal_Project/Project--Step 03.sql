--Show table
select * from EmployeeLogin