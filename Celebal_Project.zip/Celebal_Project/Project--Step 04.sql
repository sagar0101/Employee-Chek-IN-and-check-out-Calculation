--Calculate First Check-in Time, Last Check-out Time, aur Total Work Hours:
WITH EmployeeCheckInOut AS (
    SELECT 
        EmpID, 
        Name,
        CheckInCheckOutTime,
        Attendance,
        ROW_NUMBER() OVER (PARTITION BY EmpID ORDER BY CheckInCheckOutTime) AS RowNum
    FROM EmployeeLogin
),
EmployeeFirstLastCheck AS (
    SELECT 
        EmpID,
        Name,
        MIN(CASE WHEN Attendance = 'IN' THEN CheckInCheckOutTime END) AS FirstCheckInTime,
        MAX(CASE WHEN Attendance = 'OUT' THEN CheckInCheckOutTime END) AS LastCheckOutTime
    FROM EmployeeCheckInOut
    GROUP BY EmpID, Name
),
EmployeeSessions AS (
    SELECT 
        EmpID, 
        Name,
        CheckInCheckOutTime AS CheckInTime,
        LEAD(CheckInCheckOutTime) OVER (PARTITION BY EmpID ORDER BY CheckInCheckOutTime) AS CheckOutTime,
        ROW_NUMBER() OVER (PARTITION BY EmpID ORDER BY CheckInCheckOutTime) AS RowNum
    FROM EmployeeLogin
    WHERE Attendance = 'IN'
),
EmployeeWorkHours AS (
    SELECT 
        EmpID, 
        Name,
        SUM(DATEDIFF(MINUTE, CheckInTime, CheckOutTime)) AS TotalWorkMinutes
    FROM EmployeeSessions
    WHERE CheckOutTime IS NOT NULL
    GROUP BY EmpID, Name
)
SELECT 
    f.EmpID,
    f.Name,
    f.FirstCheckInTime,
    f.LastCheckOutTime,
    (SELECT COUNT(*) FROM EmployeeSessions WHERE EmpID = f.EmpID) AS TotalOutCount,
    CONVERT(VARCHAR, (w.TotalWorkMinutes / 60)) + ':' + RIGHT('0' + CONVERT(VARCHAR, (w.TotalWorkMinutes % 60)), 2) AS TotalWorkHours
FROM EmployeeFirstLastCheck f
JOIN EmployeeWorkHours w ON f.EmpID = w.EmpID;
